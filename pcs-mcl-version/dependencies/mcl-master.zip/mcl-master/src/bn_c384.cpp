/*
	implementation of mclBn_* apis
*/
#define MCLBN_FP_UNIT_SIZE 6
#include "bn_c_impl.hpp"

