[![Build Status](https://travis-ci.org/herumi/cybozulib.png)](https://travis-ci.org/herumi/cybozulib)

cybozulib
=====

Abstract
-----
This is a tiny C++ library for Windows and Linux.


How to use
-----

directory position

    <work dir>/cybozulib
              /cybozulib_ext ; necessary for Windows if use zlib or openssl

License
-----
BSD 3-Clause License

Copyright (c) 2012 Cybozu Labs, Inc. All rights reserved.

sais.hxx
-----
sais.hxx is written by Yuta Mori.

